import React from 'react'

const App = () => {
	return (
		<div className='app'>
			<h1>React Electron Boilerplate</h1>
			<p>This is a simple boilerplate for using React with Electron</p>
		</div>
	)
}

export default App
